﻿namespace OtelYonetimMVC.Models
{
    public class RoomStatusVM
    {
        public int RoomNumber { get; set; }
        public string Status { get; set; } = "Boş";
    }
}
