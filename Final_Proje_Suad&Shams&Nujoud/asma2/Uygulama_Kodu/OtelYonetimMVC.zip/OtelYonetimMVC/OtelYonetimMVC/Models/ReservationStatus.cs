﻿namespace OtelYonetimMVC.Models
{
    public enum ReservationStatus
    {
        CheckIn,
        CheckOut,
        Completed
    }

}
