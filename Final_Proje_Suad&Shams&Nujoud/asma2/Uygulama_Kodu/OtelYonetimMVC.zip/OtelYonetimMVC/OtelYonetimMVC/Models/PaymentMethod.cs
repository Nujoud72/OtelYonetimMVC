﻿namespace OtelYonetimMVC.Models
{
    public enum PaymentMethod
    {
        Cash = 0,
        CreditCard = 1
    }
}
